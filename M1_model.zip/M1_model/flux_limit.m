function Gstar = flux_limit(HO_Flux, LO_Flux, Nz, u, psi2, dt, dz, source_strength, sigma_a, sigma_s)
    ip0c=[1:Nz]'; ip1c=[2:Nz 1]'; im1c=[Nz 1:Nz-1]';
    flux = [u(2,:); psi2];
    fAe = HO_Flux - LO_Flux; % Gleichung (11)

    % Local bounds
    umax = max(u(:,im1c), max(u(:,ip0c), u(:,ip1c))); % Gleichung (24a) mit Gleichung (22)
    umin = min(u(:,im1c), min(u(:,ip0c), u(:,ip1c))); % Gleichung (24a) mit Gleichung (22) 

    % Scaled bar states
    % Im Buch (3.72) aber mit lambda = 2*d_ij multipliziert
    wbar = 0.5 * (u(:,ip0c)+u(:,ip1c)) - 0.5 * (flux(:,ip1c) - flux(:,ip0c)) + source_term(Nz, source_strength) - reaction(u, sigma_a, sigma_s); 

    % Flux limiting
    % f_ij max (Unter Gleichung (3.77))
    fAe = min(max(0,fAe), min(umax(:,ip0c) - wbar, wbar - umin(:,ip1c))) ...
        + max(min(0,fAe), max(umin(:,ip0c) - wbar, wbar - umax(:,ip1c))); % Gleichung (27)

    % Flux correction
    Gstar = LO_Flux - fAe;
    uplus = wbar(:,im1c) + Gstar(:,im1c);
    uminus = wbar(:,ip1c) - Gstar(:,ip1c);
    Gstar = 1/dz * (uplus - u + uminus - u);
end
