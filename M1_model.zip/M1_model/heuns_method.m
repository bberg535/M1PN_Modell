function [u, uPN] = heuns_method(u, uPN, dt, dz, flux, Nz, sigma_a, sigma_s, ilim, N, source_strength, legpols)
    im1c = [Nz, 1:Nz-1];

    switch ilim
        case 1
            method = @MCL;
        case -1
            method = @LLF;
        otherwise
            method = @LW;
    end  

    z = (dz/2 : dz : 2 - dz/2);
    %% Stufe 1
    % G* berechnen
    f1 = real_HO_flux(uPN, u, dt, dz, method, flux, Nz, N, source_strength, sigma_a, sigma_s);

    % Rechte Seite berechnen
    %rhs1 = -(f1 - f1(:,im1c))/dz + source_term(Nz, source_strength) - reaction(u, sigma_a, sigma_s);
    
    % u^n Tilde
    u1 = u + dt * f1;

    % Parallel uPN^n Tilde berechnen
    k1PN = advance_pn(uPN, N, ilim, dt, dz);
    uPN1 = uPN + dt * k1PN;
    uPN1 = pn_relax_isotropic(uPN1, N, dt, sigma_a, sigma_s, source_strength);

    %% Stufe 2
    f2 = real_HO_flux(uPN1, u1, dt, dz, method, flux, Nz, N, source_strength, sigma_a, sigma_s);
    %rhs2 = -(f2 - f2(:,im1c))/dz + source_term(Nz, source_strength) - reaction(u1, sigma_a, sigma_s);

    u2 = u1 + dt * f2;

    k2PN = advance_pn(uPN1, N, ilim, dt, dz);
    uPN2 = uPN1 + dt * k2PN;
    uPN2 = pn_relax_isotropic(uPN2, N, dt, sigma_a, sigma_s, source_strength);

    %% Zeitschritt
    u   = 0.5 * (u + u2);
    uPN = 0.5 * (uPN + uPN2);
end